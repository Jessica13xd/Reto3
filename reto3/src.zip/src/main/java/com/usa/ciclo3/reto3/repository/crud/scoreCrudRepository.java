package com.usa.ciclo3.reto3.repository.crud;

import com.usa.ciclo3.reto3.model.Score;
import org.springframework.data.repository.CrudRepository;

public interface scoreCrudRepository extends CrudRepository<Score, Integer> {
}
