package com.usa.ciclo3.reto3.repository.crud;

import com.usa.ciclo3.reto3.model.Message;
import org.springframework.data.repository.CrudRepository;

public interface messageCrudRepository extends CrudRepository<Message, Integer> {
}
